package com.getitdone;

public class Parent {
	static {
		System.out.println("Parent class .class file loading..");
	}
	public Parent() {
		System.out.println("Parent class constructor called");
	}

}
