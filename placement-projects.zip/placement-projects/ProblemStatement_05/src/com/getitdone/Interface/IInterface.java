package com.getitdone.Interface;

public interface IInterface {
	
	public String saveName(String name);
	public String saveAddress(String addr);
	public String saveage(Integer age);

}
