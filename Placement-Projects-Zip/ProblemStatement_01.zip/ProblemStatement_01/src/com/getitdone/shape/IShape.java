package com.getitdone.shape;

public interface IShape {
	
	public float calcArea();
	public float calcPerimeter();

}
