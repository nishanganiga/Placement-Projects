package com.getitdone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProblemStatement24Application {

	public static void main(String[] args) {
		SpringApplication.run(ProblemStatement24Application.class, args);
	}

}
