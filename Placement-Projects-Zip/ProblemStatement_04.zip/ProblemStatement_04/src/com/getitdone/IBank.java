package com.getitdone;

public interface IBank {
	
	public String deposit(Float deposit);
	public String withdrawal(Float withdrawal);

}
