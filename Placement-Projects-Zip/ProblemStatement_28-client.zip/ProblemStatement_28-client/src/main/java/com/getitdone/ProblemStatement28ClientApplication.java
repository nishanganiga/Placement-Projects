package com.getitdone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProblemStatement28ClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProblemStatement28ClientApplication.class, args);
	}

}
